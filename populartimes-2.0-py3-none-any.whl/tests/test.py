import populartimes
from pprint import pprint
import logging

logging.getLogger().setLevel(logging.INFO)

key = "AIzaSyDOT4MIrfzdH7rhHt2J5obO2YC2q41UQaA"  # Add your API key

# deutsches museum
# (48.128442,11.581105), (48.130969, 11.584710)

# old
# (48.142199, 11.566126), (48.132986, 11.580047)

# innenstadt
# (48.132751, 11.565834), (48.142417,11.584288)

if __name__ == "__main__":
    # TESTING CURRENT POPULARITY
    # smallz jazz club NY: ChIJu55raJRZwokReRL9b1tLmQo
    # deutsches museum: ChIJ01CaE2PfnUcRUpb8Ylg-UXo
    pprint(populartimes.get_current_popular_times(key, "ChIJ01CaE2PfnUcRUpb8Ylg-UXo"))

    # TESTING FOR VERY LARGE AREA
    # pprint(populartimes.get(key, ["bar"], (48.132751, 11.565834), (48.142417,11.584288), radius=180, n_threads=1))


    pprint(populartimes.get(key, ["museum"], (48.128442, 11.581105), (48.130969, 11.584710),
                            radius=180, n_threads=10,
                            all_places=False))
                            

